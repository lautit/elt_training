var page = 'index.html';

function loadPage(element) {
	if(element.type)
}

$(document).ready(function () {
	
	
	
});