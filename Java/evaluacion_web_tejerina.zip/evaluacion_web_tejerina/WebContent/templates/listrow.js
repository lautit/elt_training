<tr>
	<td>1</td>
	<td>Lautaro</td>
	<td>Tejerina</td>
	<td>Bulnes 1845</td>
	<td>CABA</td>
	<td>M</td>
	<td>
		<ul class="list-group">
			<li class="list-group-item">Cras justo odio</li>
			<li class="list-group-item">Dapibus ac facilisis in</li>
			<li class="list-group-item">Morbi leo risus</li>
			<li class="list-group-item">Porta ac consectetur ac</li>
			<li class="list-group-item">Vestibulum at eros</li>
		</ul>
	</td>
	<td>Notas</td>
	<td>Ver Editar Eliminar</td>
</tr>
